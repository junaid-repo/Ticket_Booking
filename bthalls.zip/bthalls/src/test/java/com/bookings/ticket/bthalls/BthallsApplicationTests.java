package com.bookings.ticket.bthalls;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BthallsApplicationTests {

	@Test
	void contextLoads() {
	}

}
