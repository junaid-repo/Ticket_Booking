package com.bookings.ticket.bthalls;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BthallsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BthallsApplication.class, args);
	}

}
