package com.bookings.ticket.btusers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BtusersApplicationTests {

	@Test
	void contextLoads() {
	}

}
