package com.bookings.ticket.btmovies;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BtmoviesApplication {

	public static void main(String[] args) {
		SpringApplication.run(BtmoviesApplication.class, args);
	}

}
