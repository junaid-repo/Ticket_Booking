package com.bookings.ticket.btaccounts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BtaccountsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BtaccountsApplication.class, args);
	}

}
