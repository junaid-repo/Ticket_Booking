package com.bookings.ticket.btaccounts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BtaccountsApplicationTests {

	@Test
	void contextLoads() {
	}

}
