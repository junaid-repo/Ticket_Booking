package com.bookings.ticket.btseats;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BtseatsApplicationTests {

	@Test
	void contextLoads() {
	}

}
