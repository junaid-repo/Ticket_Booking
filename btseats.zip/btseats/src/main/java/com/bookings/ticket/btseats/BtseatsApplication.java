package com.bookings.ticket.btseats;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BtseatsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BtseatsApplication.class, args);
	}

}
